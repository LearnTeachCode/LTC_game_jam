<a href="https://e-a-n.github.io/pathLight-staging/">
    <div align="center">
        <img src="https://raw.githubusercontent.com/E-A-N/pathLight-staging/master/Title_Image_For_Git.png">
    </div>
</a>

## Contributors

<a href="https://github.com/E-A-N">
    <img width="100" height="100" src="https://avatars1.githubusercontent.com/u/17329104?s=460&v=4">
</a>
<a href="http://www.michellebrenner.com/">
    <img width="100" height="100" src="https://avatars3.githubusercontent.com/u/10392961?s=400&v=4">
</a>
<a href="http://kayleighjaffe.weebly.com/">
    <img width="100" height="100" src="https://avatars2.githubusercontent.com/u/36217497?s=460&v=4">
</a>
<a href="https://github.com/hectora23">
    <img width="100" height="100" src="https://avatars3.githubusercontent.com/u/36217411?s=460&v=4">
</a>
<a href="https://www.linkedin.com/in/daniel-hsu-aa645627/">
    <img width="100" height="100" src="https://avatars0.githubusercontent.com/u/26889220?s=460&v=4">
</a>
